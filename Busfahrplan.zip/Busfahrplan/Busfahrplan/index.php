<?php
$backgroundImage = '/x.jpg'; // Pfad zum Hintergrundbild

$pages = [
    'Startseite' => './',
    'Fahrt' => 'fahrt',
    'Fahrzeit' => 'fahrzeit',
    'Haltestelle' => 'haltestelle',
    'Linie' => 'linie'
];
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Busfahrplan</title>
    <style>
        body {
            background: url('<?php echo $backgroundImage; ?>') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            text-align: center;
            color: white;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background: #0047AB; /* Cobalt blue */
            padding: 15px 0;
            display: flex;
            justify-content: center;
            gap: 50px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s ease-in-out;
        }
        .navbar a:hover {
            background: rgba(255, 255, 255, 0.6);
            color: black;
        }
        .container {
            margin-top: 100px;
        }
        .container h1 {
            color: black;
            font-size: 25px;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <?php foreach ($pages as $name => $link): ?>
            <a href="<?php echo $link; ?>"><?php echo $name; ?></a>
        <?php endforeach; ?>
    </nav>
    <div class="container">
        <h1>Busfahrplan</h1>
    </div>
</body>
</html>
