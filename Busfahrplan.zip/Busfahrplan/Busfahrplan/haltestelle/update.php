<?php 

require dirname(__DIR__). "/connect/connect.php";

$id = $_GET['id'];

// Abfrage des aktuellen Datensatzes aus der "haltestelle"-Tabelle
$stmt2 = $pdo->prepare("SELECT * FROM haltestelle WHERE id=:id;");
$stmt2->bindValue(':id', $id);
$stmt2->execute();
$haltestelle = $stmt2->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $haltestellenname = $_POST['haltestellenname'];

    // Update der "haltestelle"-Tabelle
    $stmt = $pdo->prepare('UPDATE haltestelle SET haltestellenname=:haltestellenname WHERE id=:id');

    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':haltestellenname', $haltestellenname);

    $stmt->execute();

    header('Location: ./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Haltestelle bearbeiten</title>
</head>
<body>
    <form action="" method="POST">
        <label for="haltestellenname">Haltestellenname:</label>
        <input type="text" id="haltestellenname" name="haltestellenname" required value="<?php echo $haltestelle[0]["haltestellenname"]; ?>">
        <br><br>
        <button type="submit">Absenden</button>
    </form>
</body>
</html>
