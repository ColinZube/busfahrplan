<?php

require dirname(__DIR__). "/connect/connect.php";

if(isset($_GET['id'])){
    
    $id = (int) $_GET['id'];

    $stmt = $pdo->prepare('DELETE FROM `haltestelle` where `id` = :id');

    $stmt->bindValue(':id',$id);

    $stmt->execute();

    header('location: ./index.php');

}
?>