<?php
$pages = [
    'Startseite' => './../',
    'Fahrt' => './../fahrt',
    'Fahrzeit' => './../fahrzeit',
    'Haltestelle' => './',
    'Linie' => './../linie'
];

require __DIR__ . '/../connect/connect.php';

// Abrufen aller Datensätze aus der "haltestelle" Datenbank
$stmt = $pdo->prepare("  
    SELECT   
        id,  
        haltestellenname   
    FROM haltestelle
");
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Haltestelle</title>
    <style>
        body {
            background-size: cover;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: black;
        }
        .navbar {
            background: #0047AB; /* Cobalt blue */
            padding: 15px 0;
            display: flex;
            justify-content: center;
            gap: 50px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s ease-in-out;
        }
        .navbar a:hover {
            background: rgba(255, 255, 255, 0.6);
            color: black;
        }
        .container {
            margin-top: 100px;
            text-align: center;
        }
        h1 {
            color: black;
            font-size: 25px;
        }
        table {
            width: 70%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .actions button {
            border: none;
            padding: 8px 12px;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .update {
            background-color: #4CAF50;
        }
        .delete {
            background-color: #f44336;
        }
        .add_ski_btn {
            display: inline-block;
            background-color: #008CBA;
            color: white;
            padding: 10px 20px;
            margin-top: 20px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 18px;
            transition: background 0.3s ease-in-out;
        }
        .add_ski_btn:hover {
            background: #005f74;
        }
        /* Grundlegende Button-Stile */
        .btn {
            padding: 10px 15px;
            font-size: 14px;
            border-radius: 5px;
            text-align: center;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
            transition: background-color 0.3s ease;
        }

        .edit_btn {
            background-color: #4CAF50; /* Grüner Hintergrund für "Update" */
        }

        .edit_btn:hover {
            background-color: #45a049; /* Etwas dunklerer Grünton beim Hover */
        }

        .delete_btn {
            background-color: #f44336; /* Roter Hintergrund für "Delete" */
        }

        .delete_btn:hover {
            background-color: #e53935; /* Etwas dunklerer Rotton beim Hover */
        }
    </style>
</head>
<body>
    <!-- Blaue Navigationsleiste -->
    <nav class="navbar">
        <?php foreach ($pages as $name => $link): ?>
            <a href="<?php echo $link; ?>"><?php echo $name; ?></a>
        <?php endforeach; ?>
    </nav>

    <div class="container">
        <h1>Haltestelle</h1>

        <!-- Tabelle mit den Haltestellen-Daten -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Haltestellenname</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['haltestellenname']; ?></td>
                        <td><a href="update.php?id=<?php echo $row['id']; ?>" class="btn edit_btn">Update</a></td>
                        <td><a href="delete.php?id=<?php echo $row['id']; ?>" class="btn delete_btn">Delete</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Button zum Hinzufügen einer neuen Haltestelle -->
        <a href="insert.php" class="add_ski_btn">Neue Haltestelle hinzufügen</a>
    </div>

</body>
</html>
