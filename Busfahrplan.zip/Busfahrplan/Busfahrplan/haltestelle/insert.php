<?php
require dirname(__DIR__) . "/connect/connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['haltestellenname'])) {
        $haltestellenname = $_POST['haltestellenname'];

        $stmt = $pdo->prepare("INSERT INTO haltestelle (haltestellenname) VALUES (:haltestellenname)");
        
        $stmt->bindValue(':haltestellenname', $haltestellenname, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            header("Location: ./index.php");
            exit();
        } else {
            echo "Fehler: Datensatz konnte nicht hinzugefügt werden.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neue Haltestelle hinzufügen</title>
</head>
<body>
    <h2>Neue Haltstelle hinzufügen</h2>
    <form action="" method="POST">
        <label for="haltstellenname">Haltestellenname:</label>
        <input type="text" id="haltestellenname" name="haltestellenname" required>
        <br><br>
        
        <button type="submit">Hinzufügen</button>
    </form>
</body>
</html>
