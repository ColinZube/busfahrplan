<?php
require dirname(__DIR__) . "/connect/connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['linie_id'], $_POST['fahrtzeit'])) {
        $linie_id = $_POST['linie_id'];
        $fahrtzeit = $_POST['fahrtzeit'];

        $stmt = $pdo->prepare("INSERT INTO fahrt (linie_id, fahrtzeit) VALUES (:linie_id, :fahrtzeit)");
        
        $stmt->bindValue(':linie_id', $linie_id, PDO::PARAM_INT);
        $stmt->bindValue(':fahrtzeit', $fahrtzeit, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            header("Location: ./index.php");
            exit();
        } else {
            echo "Fehler: Datensatz konnte nicht hinzugefügt werden.";
        }
    }
}

// Abrufen aller Linien für die Dropdown-Liste
$stmt_linie = $pdo->prepare("SELECT id, linienname FROM linie");
$stmt_linie->execute();
$linien = $stmt_linie->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neue Fahrt hinzufügen</title>
</head>
<body>
    <h2>Neue Fahrt hinzufügen</h2>
    <form action="" method="POST">
        <label for="linie_id">Linie:</label>
        <select id="linie_id" name="linie_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($linien as $linie): ?>
                <option value="<?php echo $linie['id']; ?>">
                    <?php echo htmlspecialchars($linie['linienname']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br><br>
        
        <label for="fahrtzeit">Fahrtzeit:</label>
        <input type="time" id="fahrtzeit" name="fahrtzeit" required>
        <br><br>
        
        <button type="submit">Hinzufügen</button>
    </form>
</body>
</html>