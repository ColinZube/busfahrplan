<?php 

require dirname(__DIR__). "/connect/connect.php";

$id = $_GET['id'];

$stmt2 = $pdo->prepare("SELECT * FROM fahrt WHERE id=:id;");
$stmt2->bindValue(':id', $id, PDO::PARAM_INT);
$stmt2->execute();
$fahrt = $stmt2->fetch(PDO::FETCH_ASSOC);

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $linie_id = $_POST['linie_id'];
    $fahrtzeit = $_POST['fahrtzeit'];

    $stmt = $pdo->prepare('UPDATE fahrt SET linie_id=:linie_id, fahrtzeit=:fahrtzeit WHERE id=:id');

    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->bindValue(':linie_id', $linie_id, PDO::PARAM_INT);
    $stmt->bindValue(':fahrtzeit', $fahrtzeit, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        header('Location: ./index.php');
        exit();
    } else {
        echo "Fehler: Datensatz konnte nicht aktualisiert werden.";
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fahrt aktualisieren</title>
</head>
<body>
    <h2>Fahrt aktualisieren</h2>
    <form action="" method="POST">
        <label for="linie_id">Linie ID:</label>
        <input type="number" id="linie_id" name="linie_id" required value="<?php echo htmlspecialchars($fahrt['linie_id']); ?>">
        <br><br>

        <label for="fahrtzeit">Fahrtzeit:</label>
        <input type="text" id="fahrtzeit" name="fahrtzeit" required value="<?php echo htmlspecialchars($fahrt['fahrtzeit']); ?>">
        <br><br>

        <button type="submit">Speichern</button>
    </form>
</body>
</html>
