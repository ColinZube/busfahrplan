<?php
require dirname(__DIR__) . "/connect/connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['linienname'])) {
        $linienname = $_POST['linienname'];

        $stmt = $pdo->prepare("INSERT INTO linie (linienname) VALUES (:linienname)");
        
        $stmt->bindValue(':linienname', $linienname, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            header("Location: ./index.php");
            exit();
        } else {
            echo "Fehler: Datensatz konnte nicht hinzugefügt werden.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neue Linie hinzufügen</title>
</head>
<body>
    <h2>Neue Linie hinzufügen</h2>
    <form action="" method="POST">
        <label for="linienname">Linienname:</label>
        <input type="text" id="linienname" name="linienname" required>
        <br><br>
        
        <button type="submit">Hinzufügen</button>
    </form>
</body>
</html>
