<?php 

require dirname(__DIR__). "/connect/connect.php";

$id = $_GET['id'];

// Abfrage des aktuellen Datensatzes aus der "linie"-Tabelle
$stmt2 = $pdo->prepare("SELECT * FROM linie WHERE id=:id;");
$stmt2->bindValue(':id', $id);
$stmt2->execute();
$linie = $stmt2->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $linienname = $_POST['linienname'];

    // Update der "linie"-Tabelle
    $stmt = $pdo->prepare('UPDATE linie SET linienname=:linienname WHERE id=:id');

    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':linienname', $linienname);

    $stmt->execute();

    header('Location: ./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Linie bearbeiten</title>
</head>
<body>
    <form action="" method="POST">
        <label for="linienname">Linienname:</label>
        <input type="text" id="linienname" name="linienname" required value="<?php echo $linie[0]["linienname"]; ?>">
        <br><br>
        <button type="submit">Absenden</button>
    </form>
</body>
</html>
