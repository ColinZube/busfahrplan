<?php
require dirname(__DIR__) . "/connect/connect.php";

// Alle Haltestellen abrufen
$stmtHaltestellen = $pdo->query("SELECT id, haltestellenname FROM haltestelle");
$haltestellen = $stmtHaltestellen->fetchAll(PDO::FETCH_ASSOC);

// Alle Fahrten abrufen
$stmtFahrten = $pdo->query("SELECT id, fahrtzeit FROM fahrt");
$fahrten = $stmtFahrten->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['haltestelle_id'], $_POST['fahrt_id'], $_POST['ankunftszeit'], $_POST['abfahrtszeit'])) {
        $haltestelle_id = $_POST['haltestelle_id'];
        $fahrt_id = $_POST['fahrt_id'];
        $ankunftszeit = $_POST['ankunftszeit'];
        $abfahrtszeit = $_POST['abfahrtszeit'];

        $stmt = $pdo->prepare("INSERT INTO fahrzeit (haltestelle_id, fahrt_id, ankunftszeit, abfahrtszeit) VALUES (:haltestelle_id, :fahrt_id, :ankunftszeit, :abfahrtszeit)");
        
        $stmt->bindValue(':haltestelle_id', $haltestelle_id, PDO::PARAM_INT);
        $stmt->bindValue(':fahrt_id', $fahrt_id, PDO::PARAM_INT);
        $stmt->bindValue(':ankunftszeit', $ankunftszeit, PDO::PARAM_STR);
        $stmt->bindValue(':abfahrtszeit', $abfahrtszeit, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            header("Location: ./index.php");
            exit();
        } else {
            echo "Fehler: Datensatz konnte nicht hinzugefügt werden.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Neue Fahrzeit hinzufügen</title>
</head>
<body>
    <h2>Neue Fahrzeit hinzufügen</h2>
    <form action="" method="POST">
        <label for="haltestelle_id">Haltestelle:</label>
        <select id="haltestelle_id" name="haltestelle_id" required>
            <option value="">-- Wähle eine Haltestelle --</option>
            <?php foreach ($haltestellen as $haltestelle): ?>
                <option value="<?= $haltestelle['id'] ?>"><?= htmlspecialchars($haltestelle['haltestellenname']) ?></option>
            <?php endforeach; ?>
        </select>
        <br><br>
        
        <label for="fahrt_id">Fahrt:</label>
        <select id="fahrt_id" name="fahrt_id" required>
            <option value="">-- Wähle eine Fahrtzeit --</option>
            <?php foreach ($fahrten as $fahrt): ?>
                <option value="<?= $fahrt['id'] ?>"><?= htmlspecialchars($fahrt['fahrtzeit']) ?></option>
            <?php endforeach; ?>
        </select>
        <br><br>

        <label for="ankunftszeit">Ankunftszeit:</label>
        <input type="time" id="ankunftszeit" name="ankunftszeit" required>
        <br><br>
        
        <label for="abfahrtszeit">Abfahrtszeit:</label>
        <input type="time" id="abfahrtszeit" name="abfahrtszeit" required>
        <br><br>
        
        <button type="submit">Hinzufügen</button>
    </form>
</body>
</html>
