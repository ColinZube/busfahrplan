<?php 

require dirname(__DIR__). "/connect/connect.php";

$id = $_GET['id'];

$stmt2 = $pdo->prepare("select * from fahrzeit where id=:id;");
$stmt2->bindValue(':id', $id);
$stmt2->execute();
$fahrplan = $stmt2->fetchAll(PDO::FETCH_ASSOC);

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $haltestelle_id = $_POST['haltestelle_id'];
    $fahrt_id = $_POST['fahrt_id'];
    $ankunftszeit = $_POST['ankunftszeit'];
    $abfahrtszeit = $_POST['abfahrtszeit'];

    $stmt = $pdo->prepare('UPDATE fahrzeit SET haltestelle_id=:haltestelle_id, fahrt_id=:fahrt_id, ankunftszeit=:ankunftszeit, abfahrtszeit=:abfahrtszeit WHERE id=:id');

    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':haltestelle_id', $haltestelle_id);
    $stmt->bindValue(':fahrt_id', $fahrt_id);
    $stmt->bindValue(':ankunftszeit', $ankunftszeit);
    $stmt->bindValue(':abfahrtszeit', $abfahrtszeit);
    
    $stmt->execute();

    header('location: ./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Formular</title>
</head>
<body>
    <form action="" method="POST">
        <label for="haltestelle_id">Haltestellen ID:</label>
        <input type="number" id="haltestelle_id" name="haltestelle_id" required value="<?php echo $fahrplan[0]["haltestelle_id"];?>">
        <br><br>
        <label for="fahrt_id">Fahrt ID:</label>
        <input type="text" id="fahrt_id" name="fahrt_id" required value="<?php echo $fahrplan[0]["fahrt_id"];?>">
        <br><br>
        <label for="ankunftszeit">Ankunftszeit:</label>
        <input type="time" id="ankunftszeit" name="ankunftszeit" required value="<?php echo $fahrplan[0]["ankunftszeit"];?>">
        <br><br>
        <label for="abfahrtszeit">Abfahrtszeit:</label>
        <input type="time" id="abfahrtszeit" name="abfahrtszeit" required value="<?php echo $fahrplan[0]["abfahrtszeit"];?>">
        <br><br>
        <button type="submit">Absenden</button>
    </form>
</body>
</html>